/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ke.co.miles.kcep.mis.utilities;

import java.io.Serializable;

/**
 *
 * @author siech
 */
public class ComponentDetails implements Serializable, Comparable<ComponentDetails> {

    private static final long serialVersionUID = 1L;

    public ComponentDetails() {
    }

    public ComponentDetails(Short id) {
        this.id = id;
    }

    public Short getId() {
        return id;
    }

    public void setId(Short id) {
        this.id = id;
    }

    public String getComponent() {
        return component;
    }

    public void setComponent(String component) {
        this.component = component;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof ComponentDetails)) {
            return false;
        }
        ComponentDetails other = (ComponentDetails) object;
        return !((this.id == null && other.getId() != null) || (this.id != null && !this.id.equals(other.getId())));
    }

    @Override
    public String toString() {
        return "ke.co.miles.kcep.mis.entities.Component[ component=" + component + " ]";
    }

    @Override
    public int compareTo(ComponentDetails o) {
        return this.id.compareTo(o.getId());
    }

    private Short id;
    private String component;

}
