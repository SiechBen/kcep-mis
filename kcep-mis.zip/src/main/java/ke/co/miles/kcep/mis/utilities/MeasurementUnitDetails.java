/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ke.co.miles.kcep.mis.utilities;

import java.io.Serializable;

/**
 *
 * @author siech
 */
public class MeasurementUnitDetails implements Serializable, Comparable<MeasurementUnitDetails> {

    private static final long serialVersionUID = 1L;

    public MeasurementUnitDetails() {
    }

    public MeasurementUnitDetails(Short id) {
        this.id = id;
    }

    public Short getId() {
        return id;
    }

    public void setId(Short id) {
        this.id = id;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof MeasurementUnitDetails)) {
            return false;
        }
        MeasurementUnitDetails other = (MeasurementUnitDetails) object;
        return !((this.id == null && other.getId() != null) || (this.id != null && !this.id.equals(other.getId())));
    }

    @Override
    public String toString() {
        return "ke.co.miles.kcep.mis.utilities.MeasurementUnit[ unit=" + unit + " ]";
    }

    @Override
    public int compareTo(MeasurementUnitDetails o) {
        return this.id.compareTo(o.getId());
    }

    /**
     * @return the symbol
     */
    public String getSymbol() {
        return symbol;
    }

    /**
     * @param symbol the symbol to set
     */
    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    private Short id;
    private String unit;
    private String symbol;

}
